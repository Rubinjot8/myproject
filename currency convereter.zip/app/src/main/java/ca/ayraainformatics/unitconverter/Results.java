package ca.ayraainformatics.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

public class Results extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);


        // Get the Intent that started this activity
        Intent intent = getIntent();
        String result = intent.getStringExtra("result");

        TextView displayTextView = (TextView) findViewById(R.id.outText);



        displayTextView.setText(result);
                //Displaying Toast
                //Toast.makeText(getApplicationContext(), "Result-> :::::::::::::: " + result, Toast.LENGTH_SHORT).show();

    }
}