package ca.ayraainformatics.unitconverter;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class StocksActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    public String firstSpinnerValue = "";
    public String secondSpinnerValue = "";

    public EditText distValue;

    public ImageButton buttonConvert;

    public String[] arraySpinner;


    public String result;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_lengths);


            this.arraySpinner = new String[]{"USD", "CAD", "INR", "PAK", "EUR"};
            Spinner spinnerFrom = (Spinner) findViewById(R.id.spinnerFrom);
            Spinner spinnerTo = (Spinner) findViewById(R.id.spinnerTo);

            spinnerFrom.setOnItemSelectedListener(this);
            spinnerTo.setOnItemSelectedListener(this);

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, arraySpinner);
            spinnerFrom.setAdapter(adapter);
            spinnerTo.setAdapter(adapter);
        }

    public void convert_temp(View view) {

        EditText getnum;
        getnum = (EditText) findViewById(R.id.q);
        final double num = new Integer(getnum.getText().toString()).intValue();


            buttonConvert = (ImageButton) findViewById(R.id.buttonconvert);
            buttonConvert.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {


        if (firstSpinnerValue.equalsIgnoreCase("USD") && secondSpinnerValue.equalsIgnoreCase("CAD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 1.36);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("USD") && secondSpinnerValue.equalsIgnoreCase("INR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 74.63);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("USD") && secondSpinnerValue.equalsIgnoreCase("PAK")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 116.40);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("USD") && secondSpinnerValue.equalsIgnoreCase("EUR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.89);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("CAD") && secondSpinnerValue.equalsIgnoreCase("USD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.74);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("CAD") && secondSpinnerValue.equalsIgnoreCase("INR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.0022);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("CAD") && secondSpinnerValue.equalsIgnoreCase("PAK")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.0352);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("CAD") && secondSpinnerValue.equalsIgnoreCase("EUR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 1/1000000);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("INR") && secondSpinnerValue.equalsIgnoreCase("USD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.453);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("INR") && secondSpinnerValue.equalsIgnoreCase("CAD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 453.59 );
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("INR") && secondSpinnerValue.equalsIgnoreCase("PAK")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 16.0);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("INR") && secondSpinnerValue.equalsIgnoreCase("EUR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.000453);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("PAK") && secondSpinnerValue.equalsIgnoreCase("USD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.028);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("PAK") && secondSpinnerValue.equalsIgnoreCase("CAD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 28.34);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("PAK") && secondSpinnerValue.equalsIgnoreCase("INR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 0.0625);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("PAK") && secondSpinnerValue.equalsIgnoreCase("EUR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 1/2.83e5);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("EUR") && secondSpinnerValue.equalsIgnoreCase("USD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 1000);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("EUR") && secondSpinnerValue.equalsIgnoreCase("CAD")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 1000000);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("EUR") && secondSpinnerValue.equalsIgnoreCase("INR")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 2204.62);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }
        else if (firstSpinnerValue.equalsIgnoreCase("EUR") && secondSpinnerValue.equalsIgnoreCase("PAK")) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = (num * 35273.96);
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }

        else if (
                firstSpinnerValue.equalsIgnoreCase("USD") && secondSpinnerValue.equalsIgnoreCase("USD")
                || firstSpinnerValue.equalsIgnoreCase("CAD") && secondSpinnerValue.equalsIgnoreCase("CAD")
                || firstSpinnerValue.equalsIgnoreCase("INR") && secondSpinnerValue.equalsIgnoreCase("INR")
                        || firstSpinnerValue.equalsIgnoreCase("PAK") && secondSpinnerValue.equalsIgnoreCase("PAK")
                        || firstSpinnerValue.equalsIgnoreCase("EUR") && secondSpinnerValue.equalsIgnoreCase("EUR")
        ) {
            Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue + " :::::::::::::: " + num,Toast.LENGTH_SHORT).show();
            final double i = num;
            result = num + " " + firstSpinnerValue + " = " + i + " " + secondSpinnerValue;
        }


                    //Displaying Toast
                    Toast.makeText(getApplicationContext(), firstSpinnerValue + "->" + secondSpinnerValue +" : "+ num,Toast.LENGTH_SHORT).show();

                    //Intent to Print
                    Intent intent = new Intent(StocksActivity.this, Results.class);
                    intent.putExtra("result", result.toString());
                    startActivity(intent);
                }
            });
        }

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            Spinner spinner = (Spinner) parent;

            if(spinner.getId() == R.id.spinnerFrom){
                //do this
                firstSpinnerValue = parent.getSelectedItem().toString();
            }
            else if(spinner.getId() == R.id.spinnerTo){
                //do this
                secondSpinnerValue = parent.getSelectedItem().toString();
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }